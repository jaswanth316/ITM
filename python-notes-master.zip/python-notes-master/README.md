# python-notes
note of python
