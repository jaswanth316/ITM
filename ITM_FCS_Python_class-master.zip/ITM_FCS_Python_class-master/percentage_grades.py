a = int(input("Enter percentage :"))
if a<100 and a>=91:
    print("A")
elif a<91 and a>=81:
    print("B")
elif a<81 and a>=61:
    print("C")
elif a<61 and a>=51:
    print("D")
elif a<51 and a>=41:
    print("E")
else :
    print("FAIL")
