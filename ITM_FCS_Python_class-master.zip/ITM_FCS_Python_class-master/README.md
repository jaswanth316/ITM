ITM Python class 
